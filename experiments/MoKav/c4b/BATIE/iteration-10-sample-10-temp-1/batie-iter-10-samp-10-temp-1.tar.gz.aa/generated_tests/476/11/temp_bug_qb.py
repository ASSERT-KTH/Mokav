def original_func(*args):
	global_list = []
	
	global_list.append((((2 * int(args[0])) + 2) // 3))
	return global_list