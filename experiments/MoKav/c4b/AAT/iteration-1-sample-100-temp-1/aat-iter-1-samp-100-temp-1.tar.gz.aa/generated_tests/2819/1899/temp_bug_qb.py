def original_func(*args):
	global_list = []
	
	global_list.append(2)
	return global_list