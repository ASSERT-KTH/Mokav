def patched_func(*args):
	global_list = []
	
	a = list(map(int, args[0].split()))
	if ((a[0] > 1) & (a[1] == 1)):
	    global_list.append((- 1))
	elif (a[0] == a[1] == 1):
	    global_list.append('a')
	elif (a[1] > a[0]):
	    global_list.append((- 1))
	else:
	    global_list.append(((('ab' * (((a[0] + 2) - a[1]) // 2)) + ('a' * ((a[0] - a[1]) % 2))) + ''.join(map((lambda x: chr((ord('c') + x))), range((a[1] - 2))))))
	return global_list