def patched_func(*args):
	global_list = []
	
	n = int(args[0])
	if ((n % 2) == 0):
	    global_list.append(((n // 4) - ((n % 4) == 0)))
	else:
	    global_list.append(0)
	return global_list