
import unittest
from temp_acc_qb import patched_func as patched_source
from temp_bug_qb import original_func as original_source

class TestFunctions(unittest.TestCase):
                


    def test0(self):
        input_0 = [{'nodeA': {'value': 'A', 'successors': ['nodeB', 'nodeC']}, 'nodeB': {'value': 'B', 'successors': ['nodeD']}, 'nodeC': {'value': 'C', 'successors': ['nodeE']}, 'nodeD': {'value': 'D', 'successors': ['nodeF']}, 'nodeE': {'value': 'E', 'successors': ['nodeG']}, 'nodeF': {'value': 'F', 'successors': ['nodeG']}, 'nodeG': {'value': 'G', 'successors': []}}, 'nodeA', 'nodeG']
        self.assertEqual(patched_source(*input_0), original_source(*input_0))
            


if __name__ == '__main__':
    unittest.main()  
    
    